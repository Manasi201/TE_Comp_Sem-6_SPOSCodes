package spos;

import java.io.*;
import java.util.*;
class spos 
{
public static void main(String args[])
{
String REG[];
if(a<b)
}
}
