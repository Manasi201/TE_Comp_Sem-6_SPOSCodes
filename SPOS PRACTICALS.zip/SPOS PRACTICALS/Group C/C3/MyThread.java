import java.io.*;
import java.util.*;
public class MyThread extends Thread
{
	static int a,b;
	public void run()
   	{
       		System.out.println("r1 ");
		//System.out.println("a = "+a+"\tb = "+b);
       		try {
        		Thread.sleep(500);
    		}catch(InterruptedException ie){ }
       		System.out.println("r2 ");
		a=a*a;b=b*b;
		System.out.println("a = "+a+"b = "+b);
  	}
	public static void main(String[] args)
	{
		MyThread t1=new MyThread();
		MyThread t2=new MyThread();
		t1.start();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value of a : ");
		a=sc.nextInt();
		System.out.println("Enter value of a : ");
		b=sc.nextInt();
		System.out.println("a = "+a+"\tb = "+b);
		try{
  			t1.join();	//Waiting for t1 to finish
		}catch(InterruptedException ie){}

		t2.start();
	}
}
