public class process
{
	int pid,st,ft,prior;
	int wt,tat,at,bt;
	int flag;
};
