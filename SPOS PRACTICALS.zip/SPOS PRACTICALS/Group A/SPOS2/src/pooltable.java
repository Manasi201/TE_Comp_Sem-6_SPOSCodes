
public class pooltable {
int first,total_literals;
public pooltable(int f, int l) {
	// TODO Auto-generated constructor stub
	this.first=f;
	this.total_literals=l;
}
}
